-- phpMyAdmin SQL Dump
-- version 4.6.0
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 29, 2017 at 06:57 PM
-- Server version: 5.7.11
-- PHP Version: 7.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `zone_entrepreneurs`
--
CREATE DATABASE IF NOT EXISTS `zone_entrepreneurs` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `zone_entrepreneurs`;

-- --------------------------------------------------------

--
-- Table structure for table `activation`
--

CREATE TABLE `activation` (
  `id` int(11) NOT NULL,
  `mode` varchar(150) NOT NULL,
  `activation` int(1) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `activation`
--

INSERT INTO `activation` (`id`, `mode`, `activation`) VALUES
(1, 'aucune', 1),
(2, 'mail', 0),
(3, 'manuel', 0);

-- --------------------------------------------------------

--
-- Table structure for table `activation_mail`
--

CREATE TABLE `activation_mail` (
  `id` int(11) NOT NULL,
  `id_membre` int(11) NOT NULL,
  `jeton` varchar(150) NOT NULL,
  `depot` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `footer`
--

CREATE TABLE `footer` (
  `id_footer` int(11) NOT NULL,
  `url_footer` text NOT NULL,
  `depot` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `footer`
--

INSERT INTO `footer` (`id_footer`, `url_footer`, `depot`) VALUES
(1, 'site/footer/footer.php', '2017-03-29 17:20:22'),
(2, 'site/footer/footer2.html', '2017-03-29 17:20:22'),
(3, 'site/footer/footer3.html', '2017-03-29 17:20:22');

-- --------------------------------------------------------

--
-- Table structure for table `header`
--

CREATE TABLE `header` (
  `id_header` int(11) NOT NULL,
  `url_header` text NOT NULL,
  `depot` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `header`
--

INSERT INTO `header` (`id_header`, `url_header`, `depot`) VALUES
(1, 'site/header/header.php', '2017-03-29 17:18:34'),
(2, 'site/header/header3.html', '2017-03-29 17:19:10'),
(3, 'site/header/header2.html', '2017-03-29 17:19:10'),
(4, 'site/header/header4.html', '2017-03-29 17:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `infos_administrative`
--

CREATE TABLE `infos_administrative` (
  `id_membre` int(11) NOT NULL,
  `societe` text NOT NULL,
  `localcommercial` int(11) NOT NULL,
  `date_depot` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `infos_administrative`
--

INSERT INTO `infos_administrative` (`id_membre`, `societe`, `localcommercial`, `date_depot`) VALUES
(2, 'zonee', 0, '2017-03-26 19:59:37'),
(14, 'blabla', 0, '2017-03-29 20:20:46');

-- --------------------------------------------------------

--
-- Table structure for table `membres`
--

CREATE TABLE `membres` (
  `id_membre` int(11) NOT NULL,
  `nom` text CHARACTER SET utf8 NOT NULL,
  `prenom` text CHARACTER SET utf8 NOT NULL,
  `email` text CHARACTER SET utf8 NOT NULL,
  `password` text CHARACTER SET utf8 NOT NULL,
  `adresse` text CHARACTER SET utf8,
  `codepostal` int(6) DEFAULT NULL,
  `ville` varchar(200) CHARACTER SET utf8 DEFAULT NULL,
  `telephone` int(11) DEFAULT NULL,
  `niveau` int(11) NOT NULL,
  `activation` int(11) NOT NULL DEFAULT '0',
  `url_inscription` text CHARACTER SET utf8,
  `date_depot` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `membres`
--

INSERT INTO `membres` (`id_membre`, `nom`, `prenom`, `email`, `password`, `adresse`, `codepostal`, `ville`, `telephone`, `niveau`, `activation`, `url_inscription`, `date_depot`) VALUES
(2, 'test1', 'test1', 'test1@zone.fr', '@( ãV¬ÉGüÒ¿¿\0ÎñHJ', '163 avenue de l\'europe', 92220, 'cachan', 154789854, 1, 1, NULL, '2017-03-26 19:59:37'),
(14, 'BienPro', 'nilo', 'bienpro@zone.fr', '@( ãV¬ÉGüÒ¿¿\0ÎñHJ', '47 rue de ton pere', 94587, 'au moins deux lettres', 125458789, 1, 1, 'e1r10p11.42.fr:8080', '2017-03-29 20:20:46');

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id_menu` int(11) NOT NULL,
  `url_menu` text NOT NULL,
  `depot` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id_menu`, `url_menu`, `depot`) VALUES
(1, 'site/menu/menu.php', '2017-03-29 17:21:20'),
(2, 'site/menu/menu2.html', '2017-03-29 17:21:20'),
(3, 'site/menu/menu3.html', '2017-03-29 17:21:20');

-- --------------------------------------------------------

--
-- Table structure for table `pro_check_site`
--

CREATE TABLE `pro_check_site` (
  `id_membre` int(11) NOT NULL,
  `url_header` text NOT NULL,
  `url_menu` text NOT NULL,
  `url_footer` text NOT NULL,
  `name_site` text NOT NULL,
  `date_maj` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `secure`
--

CREATE TABLE `secure` (
  `id` int(11) NOT NULL,
  `id_membre` int(11) NOT NULL,
  `jeton` varchar(255) NOT NULL,
  `ip_connexion` varchar(50) NOT NULL,
  `date` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `secure`
--

INSERT INTO `secure` (`id`, `id_membre`, `jeton`, `ip_connexion`, `date`) VALUES
(8, 2, 'Ýæ¿ñK}ûL| JçÝ{–®', '::1', '1490551502');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activation`
--
ALTER TABLE `activation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `activation_mail`
--
ALTER TABLE `activation_mail`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_membre_pro` (`id_membre`);

--
-- Indexes for table `footer`
--
ALTER TABLE `footer`
  ADD PRIMARY KEY (`id_footer`);

--
-- Indexes for table `header`
--
ALTER TABLE `header`
  ADD PRIMARY KEY (`id_header`);

--
-- Indexes for table `infos_administrative`
--
ALTER TABLE `infos_administrative`
  ADD PRIMARY KEY (`id_membre`);

--
-- Indexes for table `membres`
--
ALTER TABLE `membres`
  ADD PRIMARY KEY (`id_membre`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`);

--
-- Indexes for table `pro_check_site`
--
ALTER TABLE `pro_check_site`
  ADD KEY `id_membre` (`id_membre`);

--
-- Indexes for table `secure`
--
ALTER TABLE `secure`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_membre_pro` (`id_membre`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activation`
--
ALTER TABLE `activation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `activation_mail`
--
ALTER TABLE `activation_mail`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `footer`
--
ALTER TABLE `footer`
  MODIFY `id_footer` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `header`
--
ALTER TABLE `header`
  MODIFY `id_header` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `membres`
--
ALTER TABLE `membres`
  MODIFY `id_membre` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id_menu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `secure`
--
ALTER TABLE `secure`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

<?php session_start();

include('function.php');
if (isset($_POST['submit'])) {
	echo InscriptionPro::insertPro($_POST['email'], $_POST['password'], $_POST['conf_password']);
	if (InscriptionPro::insertPro($_POST['email'], $_POST['password'], $_POST['conf_password'])){
		InscriptionPro::insertForm(Membre::recupId($_POST['email']), $_POST['societe'], $_POST['localcommercial']);
		GenereSite::create($_POST['header'],$_POST['menu'],$_POST['footer'],$_POST['name_site']);
		redirection('index.php', $time=1);
	}
}
if (isset($_POST['submitc'])) {
	echo InscriptionClient::insertClient($_POST['email'], $_POST['password'], $_POST['passwordconf']);
	redirection('index.php', $time=2);
}
?>
			<center>
			<br />
			<img src="img/ajax-loader.gif"/>
			</center>
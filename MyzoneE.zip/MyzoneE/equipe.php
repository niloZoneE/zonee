<?php session_start();
include('header.html');
?>
<div class="container">
<div class="card-deck">
  <div class="card">
    <center>
    <img class="card-img-top" src="img/photo_identite.jpg" width="150" style="border-radius:150px;" alt="Card image cap">
    <div class="card-block">
      <h4 class="card-title">Card title</h4>
      <p class="card-text">This is a longer card with supporting text below as a natural lead-in to additional content. This content is a little bit longer.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </center>
  </div>
  <div class="card">
    <center>
    <img class="card-img-top" src="img/photo_identite.jpg" width="150" style="border-radius:150px;" alt="Card image cap">
    <div class="card-block">
      <h4 class="card-title">Card title</h4>
      <p class="card-text">This card has supporting text below as a natural lead-in to additional content.</p>
      <p class="card-text"><small class="text-muted">Last updated 3 mins ago</small></p>
    </div>
  </center>
  </div>
  <div class="card">
    <center>
    <img class="card-img-top" src="img/photo_identite.jpg" width="150" style="border-radius:150px;" alt="Card image cap">
    <div class="card-block">
      <h4 class="card-title">Card title</h4>
      <p class="card-text">This is a wider card with supporting text below as a natural lead-in to additional content. This card has even longer content than the first to show that equal height action.</p>
    </div>
  </center>
  </div>
</div>
</div>
<?php
include('footer.html');
?>
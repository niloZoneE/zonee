<?php
include('header.html');
include('menu.php');
include('footer.html');
?>

  <div class="container-fluid pro-display">
  <center>
    <div class="col-md-7" style="color: white;top: 150px;">
      <h2>loripsum kjshdfgkd rrtyh ryjfgh rhrhtgrhtrgsh</h2>
      <p>fdghjvmnbvfgdhfj fghdng hbfsdghmnbg gdfn dhrtfghj tghrsdgj ghrstdgjf gerfhs ter</p>
    </div>
  </center>
  </div>
  <div class="step container-fluid">
	<div class="row">
        <div class="col-lg-4" style="text-align:center;">
          <img src="img/form_icon.png" alt="simple form" width="140" height="140">
          <h3>Créez votre entreprise</h3>
          <p>Nous vous guiderons au fil de la création de votre nouvel entreprise, celle ci se fera totalement en ligne ! Nous vous aiderons à choisir le statut juridique qui vous convient le mieux.</p>
          <p><a class="btn btn-secondary" href="#" role="button">Je commence</a></p>
        </div>
        <div class="col-lg-4" style="text-align:center;">
          <img src="img/website.png" alt="website view" width="140" height="140">
          <h3>Designez vos plateformes</h3>
          <p>Grâce à nos outils de création simplifiés, obtenez votre site vitrine consultable sur PC et mobile totalement responsive et ce en un temps considérablement réduit. Personnalisable et modifiable à volonté, soyez maître de votre image.</p>
          <p><a class="btn btn-secondary" href="#" role="button">Un aperçu</a></p>
        </div>
        <div class="col-lg-4" style="text-align:center;">
          <img src="img/phone_view.png" alt="phone view" width="140" height="140">
          <h3>Profitez de vos outils</h3>
          <p>Vous aurez accès à des outils de gestion qui permetront d'économiser du temps précieux. Vous disposerez aussi d'une application mobile afin d'administrer efficacement votre entreprise et augmenter votre rendement.</p>
          <p><a class="btn btn-secondary" href="#" role="button">Montrez-moi</a></p>
        </div>
    </div>
</div>

<?php session_start();

copy('test.txt', 'site/')

?>
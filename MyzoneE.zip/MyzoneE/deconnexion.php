<?php session_start();
include('function.php');
Connexion::deconnexion('index.php');
?>
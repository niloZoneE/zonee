<?php
$PARAM_hote        = "localhost";
$PARAM_nom_bd      = "zone_entrepreneurs";
$PARAM_utilisateur = "root";
$PARAM_mot_passe   = "root";
$PARAM_url_site	   = "www.zone-entrepreneurs.fr";
$PARAM_mail_site   = "zone.e@zone-entrepreneurs.fr";
$PARAM_nom_site    = "zone-entrepreneurs";
?>

<?php session_start();
include('header.html');
?>
  <div class="container-fluid">
  <center>
    <div class="col-md-7">
      <h2>COIX DES TARIFS</h2>
      <p>fdghjvmnbvfgdhfj fghdng hbfsdghmnbg gdfn dhrtfghj tghrsdgj ghrstdgjf gerfhs ter</p>
    </div>
  </center>
  </div>
<div class="container-fluid" style="background-color: #d5d7d8;">
<div class="container">
	<div class="row">
		<div class="card text-center" style="width: 20rem;margin: 10px;">
			  <div class="card-header">
			    Featured
			  </div>
		  <div class="card-block">
		    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  </div>
		  <div class="card-block">
		    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  </div>
		  <ul class="list-group list-group-flush">
		    <li class="list-group-item">Cras justo odiodbgxxzb strehgrthrth</li>
		    <li class="list-group-item">Dapibus ac facilisis in terhearthgert heth eth</li>
		    <li class="list-group-item">Vestibulum at erosh etherth th therter hyehehte </li>
		    <li class="list-group-item">Cras justo odio hteh reth  rth rtasfdreg   </li>
		    <li class="list-group-item">Dapibus ac facilisis int ert rth thgh erqhg h</li>
		    <li class="list-group-item">Vestibulum at eros ert rth rthr tfdhgdg</li>
		  </ul>
		  <div class="card-block">
			<a href="#" class="btn btn-primary">GO</a>
		  </div>
		</div>

		<div class="card text-center" style="width: 20rem;margin: 10px;">
			  <div class="card-header">
			    Featured
			  </div>
		  <div class="card-block">
		    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  </div>
		  <div class="card-block">
		    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  </div>
		  <ul class="list-group list-group-flush">
		    <li class="list-group-item">Cras justo odiodbgxxzb strehgrthrth</li>
		    <li class="list-group-item">Dapibus ac facilisis in terhearthgert heth eth</li>
		    <li class="list-group-item">Vestibulum at erosh etherth th therter hyehehte </li>
		    <li class="list-group-item">Cras justo odio hteh reth  rth rtasfdreg   </li>
		    <li class="list-group-item">Dapibus ac facilisis int ert rth thgh erqhg h</li>
		    <li class="list-group-item">Vestibulum at eros ert rth rthr tfdhgdg</li>
		  </ul>
		  <div class="card-block">
			<a href="#" class="btn btn-primary">GO</a>
		  </div>
		</div>

		<div class="card text-center" style="width: 20rem;margin: 10px;">
			  <div class="card-header">
			    Featured
			  </div>
		  <div class="card-block">
		    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  </div>
		  <div class="card-block">
		    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
		  </div>
		  <ul class="list-group list-group-flush">
		    <li class="list-group-item">Cras justo odiodbgxxzb strehgrthrth</li>
		    <li class="list-group-item">Dapibus ac facilisis in terhearthgert heth eth</li>
		    <li class="list-group-item">Vestibulum at erosh etherth th therter hyehehte </li>
		    <li class="list-group-item">Cras justo odio hteh reth  rth rtasfdreg   </li>
		    <li class="list-group-item">Dapibus ac facilisis int ert rth thgh erqhg h</li>
		    <li class="list-group-item">Vestibulum at eros ert rth rthr tfdhgdg</li>
		  </ul>
		  <div class="card-block">
			<a href="#" class="btn btn-primary">GO</a>
		  </div>
		</div>
	</div>
</div>
</div>
<?php
include('footer.html');
?>